<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class ProfileController extends Controller
{
    public function __construct(Request $request)
    {
        $headers = getallheaders();
        if(!isset($headers['token']))
        {
            return response()->json(['success'=>false,'data'=>array(),'message'=>'token blanked'], 401);
        }
        $check = User::where('api_token',$request->input('token'))->first();
        if(!isset($check->id))
        {
            return response()->json(['success'=>false,'data'=>array(),'message'=>'token mis matched'], 401);
        }
    }
    //
    public function index(Request $request)
    {
        $userDetail = User::where('api_token',$request->header('token'))->first();
        if(isset($userDetail->id))
        {
            return response()->json(['success'=>true,'data'=>$userDetail,'message'=>'user pfoiel get successfully'], 200);
        }else{
            return response()->json(['success'=>false,'data'=>array(),'message'=>'user not found'], 401);
        }
    }
}
