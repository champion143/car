<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MatchRace extends Model
{
    //
    public $table = 'matchrace';
}
